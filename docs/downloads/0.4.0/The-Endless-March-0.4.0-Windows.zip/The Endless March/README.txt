THE ENDLESS MARCH: JOURNEY TO THE END

Double-click "The Endless March.exe" to play.

The game opens in its own window (Microsoft Edge in app mode, or Chrome, or
your default browser). Closing that window closes the game. F11 toggles
fullscreen. P or Esc pauses and shows the controls.

Keep the "game" folder next to the .exe: it holds the game itself. (If it is
missing, the .exe falls back to a built-in copy.)

The .exe is not code-signed, so Windows SmartScreen may warn the first time:
choose "More info" -> "Run anyway".

CONTROLS
  Move ............ Arrows / WASD (up and down walk into and out of the screen)
  Run ............. double-tap left/right, or hold Shift / C
  Jump ............ Space / Z / K
  Attack .......... X / J / left click (repeat for a three-hit combo)
  Back attack ..... F / right click, or Jump + Attack together
  Grab & throw .... attack an enemy point-blank
  Magic ........... V / Q (spends every pot you carry)
  Pause ........... P / Esc        Mute ... M
  Gamepads work too.
